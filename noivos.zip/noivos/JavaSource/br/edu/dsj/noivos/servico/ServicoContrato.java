package br.edu.dsj.noivos.servico;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import br.edu.dsj.noivos.entidade.Contrato;

/**
 * 
 * 
 * @author lucas
 *
 */
@Stateless
public class ServicoContrato {

	@PersistenceContext
	private EntityManager em;
	
	public List<Contrato> listarContratos(){
		return this.em.createQuery("FROM Contrato c", Contrato.class).getResultList();
	}
	
	public void cadastrarContrato(Contrato contrato)throws Exception {
		if(contrato.getQuantConvidados() < 100 || contrato.getQuantConvidados() > 200) {
			throw new Exception("Necessita ter mais de 100 convidados e menos de 200!");
		}if(contrato.getValorContrato() < 5200){
			throw new Exception("Contrato necessita ter um custo superior a R$5.200,00");
		}else {
			contrato.setDataEHoraDoCadastro(new Date());
			this.em.persist(contrato);
		}	
	}
	
	public void excluirContrato(Contrato contrato)throws Exception {
		if(contrato.getValorPago().equalsIgnoreCase("Sim")) {
			throw new Exception("Contrato n�o pode ser exclu�do pois j� foi pago!");
		}else {
			this.em.remove(this.em.merge(contrato));
		}
	}
}
