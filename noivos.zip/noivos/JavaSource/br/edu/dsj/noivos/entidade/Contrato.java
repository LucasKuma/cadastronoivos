package br.edu.dsj.noivos.entidade;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 
 * 
 * @author lucas
 *
 */

@Entity
public class Contrato {
	
	@Id
	@SequenceGenerator(name = "NUM_SEQ_CONTRATO", sequenceName = "NUM_SEQ_CONTRATO", allocationSize = 0)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NUM_SEQ_CONTRATO")
	private Integer id;
	
	@NotBlank
	private String noivos;
	
	@NotBlank
	private String localDoEvento;
	
	@NotBlank
	private String localDaCerimonia;
	
	private Date dataEHora;
	
	@NotBlank
	private String telefoneContato;
	
	@NotNull
	private Integer quantConvidados;
	
	@NotBlank
	private String tipoContrato;
	
	@NotNull
	private Double valorContrato;
	
	@NotBlank
	private String valorPago;
		
	private Date dataEHoraDoCadastro;
	

	public Contrato() {
		
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNoivos() {
		return noivos;
	}

	public void setNoivos(String noivos) {
		this.noivos = noivos;
	}

	public String getLocalDoEvento() {
		return localDoEvento;
	}

	public void setLocalDoEvento(String localDoEvento) {
		this.localDoEvento = localDoEvento;
	}

	public String getLocalDaCerimonia() {
		return localDaCerimonia;
	}

	public void setLocalDaCerimonia(String localDaCerimonia) {
		this.localDaCerimonia = localDaCerimonia;
	}

	public Date getDataEHora() {
		return dataEHora;
	}

	public void setDataEHora(Date dataEHora) {
		this.dataEHora = dataEHora;
	}

	public String getTelefoneContato() {
		return telefoneContato;
	}

	public void setTelefoneContato(String telefoneContato) {
		this.telefoneContato = telefoneContato;
	}

	public Integer getQuantConvidados() {
		return quantConvidados;
	}

	public void setQuantConvidados(Integer quantConvidados) {
		this.quantConvidados = quantConvidados;
	}

	public String getTipoContrato() {
		return tipoContrato;
	}

	public void setTipoContrato(String tipoContrato) {
		this.tipoContrato = tipoContrato;
	}

	public Double getValorContrato() {
		return valorContrato;
	}

	public void setValorContrato(Double valorContrato) {
		this.valorContrato = valorContrato;
	}

	public String getValorPago() {
		return valorPago;
	}

	public void setValorPago(String valorPago) {
		this.valorPago = valorPago;
	}

	public Date getDataEHoraDoCadastro() {
		return dataEHoraDoCadastro;
	}

	public void setDataEHoraDoCadastro(Date dataEHoraDoCadastro) {
		this.dataEHoraDoCadastro = dataEHoraDoCadastro;
	}

}
