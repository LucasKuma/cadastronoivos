package br.edu.dsj.noivos.web;

import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;

import javax.inject.Named;

import br.edu.dsj.noivos.entidade.Contrato;
import br.edu.dsj.noivos.servico.ServicoContrato;
import br.edu.dsj.noivos.web.util.JSFUtils;

/**
 * 
 * 
 * @author lucas
 *
 */
@Named
@RequestScoped
public class ContratoBean {

	@EJB
	private ServicoContrato servicoContrato;
	
	private Contrato contrato;
	
	public ContratoBean() {
		this.contrato = new Contrato();
	}
	
	public List<Contrato> listarContratos() {
		return this.servicoContrato.listarContratos();
	}
	
	public void cadastrarContrato()throws Exception{
		try {
			this.servicoContrato.cadastrarContrato(this.contrato);
			JSFUtils.enviarMensagemDeSucesso("Contrato cadastrado com sucesso!");
			this.contrato = new Contrato();
		}catch (Exception e) {
			JSFUtils.enviarMensagemDeAtencao(e.getMessage());
		}
	}

	public void excluirContrato(Contrato contrato)throws Exception{
		try {
			this.servicoContrato.excluirContrato(contrato);
			JSFUtils.enviarMensagemDeSucesso("Contrato exclu�do com sucesso!");
		}catch (Exception e) {
			JSFUtils.enviarMensagemDeAtencao(e.getMessage());
		}
		
	}
	
	public Contrato getContrato() {
		return contrato;
	}

	public void setContrato(Contrato contrato) {
		this.contrato = contrato;
	}

	public ServicoContrato getServicoContrato() {
		return servicoContrato;
	}

	public void setServicoContrato(ServicoContrato servicoContrato) {
		this.servicoContrato = servicoContrato;
	}
	
}
